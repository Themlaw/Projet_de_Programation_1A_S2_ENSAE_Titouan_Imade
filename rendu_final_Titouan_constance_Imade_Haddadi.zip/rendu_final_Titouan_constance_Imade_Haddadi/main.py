from interface import GameMenu

menu = GameMenu()
menu.mainloop()


